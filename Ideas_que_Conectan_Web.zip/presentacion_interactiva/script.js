const modal = document.getElementById("imageModal");
const modalImage = document.getElementById("modalImage");
const modalTitle = document.getElementById("modalTitle");

document.querySelectorAll(".view-btn").forEach(btn => {
  btn.addEventListener("click", () => {
    modalImage.src = btn.dataset.image;
    modalImage.alt = btn.dataset.title;
    modalTitle.textContent = btn.dataset.title;
    modal.classList.add("open");
    modal.setAttribute("aria-hidden", "false");
    document.body.style.overflow = "hidden";
  });
});

function closeModal() {
  modal.classList.remove("open");
  modal.setAttribute("aria-hidden", "true");
  document.body.style.overflow = "";
}
document.querySelector(".close-modal").addEventListener("click", closeModal);
document.querySelector(".modal-backdrop").addEventListener("click", closeModal);
document.addEventListener("keydown", e => {
  if (e.key === "Escape") closeModal();
});

const menuBtn = document.querySelector(".menu-btn");
const nav = document.querySelector(".navbar nav");
menuBtn.addEventListener("click", () => {
  const visible = nav.style.display === "flex";
  nav.style.display = visible ? "" : "flex";
  nav.style.flexDirection = "column";
  nav.style.position = "absolute";
  nav.style.top = "76px";
  nav.style.right = "5%";
  nav.style.padding = "18px";
  nav.style.background = "rgba(255,255,255,.97)";
  nav.style.border = "1px solid #e7e5df";
  nav.style.borderRadius = "16px";
  nav.style.boxShadow = "0 15px 35px rgba(0,0,0,.1)";
});
